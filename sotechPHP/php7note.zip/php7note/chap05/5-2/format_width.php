<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>値の最低文字数を指定する</title>
</head>
<body>
<?php
$a = 83;
$b = 92018;
$c = "3-A";
printf('番号は%04dです。', $a);
printf('番号は%04dです。', $b);
printf('IDは%04sです。', $c);
?>
</body>
</html>

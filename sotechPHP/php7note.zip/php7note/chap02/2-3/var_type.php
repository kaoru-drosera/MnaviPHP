<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>文字列の入っていた変数に数値を入れる</title>
</head>
<body>
<?php
$zaiko = "在庫なし"; // 文字列を入れる
echo $zaiko, "<br>";
$zaiko = 5; // 数値を入れる
echo $zaiko;
?>
</body>
</html>

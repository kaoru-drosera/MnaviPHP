<?php
interface WorldRule {
  function hello();
}
// ?>

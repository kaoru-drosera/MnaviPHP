<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>変数$aと$bの値を比較する</title>
</head>
<body>
<pre>
<?php
$a = 7;
$b = 10;
$hantei1 = ($a<$b);
$hantei2 = ($a>$b);
var_dump($hantei1);
var_dump($hantei2);
?>
</pre>
</body>
</html>

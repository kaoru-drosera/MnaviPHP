<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>配列を降順にソートする</title>
</head>
<body>
<pre>
<?php
$data = [23, 16, 8, 42, 15, 4];
// 降順にソートする
rsort($data);
print_r($data);
?>
</pre>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>余り</title>
</head>
<body>
<?php
$ans = 11.6%4.1;
echo $ans;
?>
</body>
</html>

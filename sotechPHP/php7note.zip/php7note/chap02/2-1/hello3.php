<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>変数を使って表示する</title>
</head>
<?php
$who = "PHP 7";
echo "こんにちは、", $who;
?>
</body>
</html>

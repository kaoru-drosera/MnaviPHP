<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>配列をarray()で作る</title>
</head>
<body>
<pre>
<?php
$colors = array("赤", "青", "黄色");
// 確認する
print_r($colors);
?>
</pre>
</body>
</html>

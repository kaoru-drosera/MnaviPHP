<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>シングルクォートの文字列にシングルクォートを含める</title>
</head>
<?php
$msg= 'そこは Y\'s ROOM です。';
echo $msg;
?>
</body>
</html>

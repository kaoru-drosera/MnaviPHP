<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>東京オリンピック開催年</title>
  <link  href="./css/style.css" rel="stylesheet" type="text/css">
</head>

<?php
$year1 = "1964年";
$year2 = "2020年";
?>

<body>
<div class="main-contents">

前回の東京オリンピックは、
<h1>
<?php echo $year1; ?>
</h1>
です。<br>
次の東京オリンピックは、
<h1>
<?php echo $year2; ?>
</h1>
です。<br>

</div>
</body>
</html>

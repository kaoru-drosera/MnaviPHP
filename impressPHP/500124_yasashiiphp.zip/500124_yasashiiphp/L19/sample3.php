<?php
$fruits = array(1=>'りんご',2=>'バナナ',3=>'メロン');
echo $fruits[1];
echo $fruits[2];
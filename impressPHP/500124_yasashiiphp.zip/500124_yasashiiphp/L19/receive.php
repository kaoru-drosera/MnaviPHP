<?php
print_r($_POST);
echo $_POST['recipe_name'];
?>
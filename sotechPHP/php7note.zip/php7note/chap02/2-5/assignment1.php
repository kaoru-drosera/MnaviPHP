<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>変数に値を代入する</title>
</head>
<body>
<pre>
<?php
$a = 100;
$b = $a + 1;
var_dump($a);
var_dump($b);
?>
</pre>
</body>
</html>

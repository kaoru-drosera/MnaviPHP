<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>文字列に値を埋め込む</title>
</head>
<body>
<?php
printf('円周率は%.2fです。', M_PI);
?>
</body>
</html>

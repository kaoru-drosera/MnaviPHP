<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>カウンタの値を減らしていく</title>
</head>
<body>
<?php
for ($i=10; $i>0; $i--){
  echo "{$i}回。";
}
?>
</body>
</html>

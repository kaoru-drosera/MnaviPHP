<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>大文字小文字の区別</title>
</head>
<?php
$myColor = "green";
$myCOLOR = "YELLOW";
echo $myColor;
echo "、";
echo $myCOLOR;
?>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>変数$a、$bの値を少数第1位で表示する</title>
</head>
<body>
<?php
$a = 15.69;
$b = 11.32;
printf('最大値%.1f、最小値%.1f', $a, $b);
?>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>変数への代入と出力</title>
</head>
<body>
<?php
$theSize = "M";
$thePrice = 1200;
echo $theSize, "サイズ、";
echo $thePrice, "円";
?>
</body>
</html>

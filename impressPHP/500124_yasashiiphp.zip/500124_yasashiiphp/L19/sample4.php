﻿<?php
$home = array('address1'=>'東京都','address2'=>'千代田区','tel'=>'03-0000-XXXX');
echo $home['address1'];
echo $home['address2'];
echo $home['tel'];
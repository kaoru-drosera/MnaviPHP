<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>配列の連結 +演算子</title>
</head>
<body>
<pre>
<?php
$a = ["a", "b", "c"];
$b = ["d", "e", "f", "g", "h"];
// 配列を連結する
$result = $a + $b;
print_r($result);
?>
</pre>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>名前の配列</title>
</head>
<body>
<pre>
<?php
// 配列を使ってチーム分けする
$teamA = ["赤井一郎", "伊藤五郎", "上野信二"];
$teamB = ["江藤幸代", "小野幸子"];

// 確認する
print_r($nameList);
?>
</pre>
</body>
</html>

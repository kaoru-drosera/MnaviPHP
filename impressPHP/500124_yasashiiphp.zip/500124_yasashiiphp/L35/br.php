<?php
echo "1行目\n";
echo "2行目\n";
echo "3行目";
echo "4行目";
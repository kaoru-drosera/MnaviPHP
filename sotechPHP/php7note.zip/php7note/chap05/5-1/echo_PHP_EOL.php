<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>OSに応じた改行で連結する</title>
</head>
<body>
<?php
echo  "あなたのことが", PHP_EOL, "大好きです";
?>
</body>
</html>

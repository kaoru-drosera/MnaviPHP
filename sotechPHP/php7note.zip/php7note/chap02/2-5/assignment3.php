<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>$aに10を加算する</title>
</head>
<body>
<?php
$a = 0;
$a += 10;
echo $a;
?>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>配列を自然順でソートする</title>
</head>
<body>
<pre>
<?php
$data = ["image7", "image12", "image1"];
// 自然順でソートする
natsort($data);
print_r($data);
?>
</pre>
</body>
</html>

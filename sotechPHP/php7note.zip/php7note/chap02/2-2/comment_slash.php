<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>コメント</title>
</head>
<body>
<?php
// この行はコメントです。
echo "こんにちは";
//
// この３行もコメントです。
//
echo "ありがとう";
?>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>合計を求めて5を引いた最終結果を出す</title>
</head>
<body>
<?php
$total = 80 + 40;
$result = $total - 5;
echo "合計{$total}、最終結果{$result}";
?>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>echoで複数の値を表示する例</title>
</head>
<body>
<?php
echo "こんにちは","<br>","ありがとう";
?>
</body>
</html>

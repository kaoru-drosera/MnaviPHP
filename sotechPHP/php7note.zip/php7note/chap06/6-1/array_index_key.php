<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>インデックス配列と連想配列</title>
</head>
<body>
<pre>
<?php
$vlist = ["a", "b", "c"];
// 確認する
print_r($vlist);
?>
</pre>
</body>
</html>

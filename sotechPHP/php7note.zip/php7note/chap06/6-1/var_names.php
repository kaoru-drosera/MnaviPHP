<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>名前を入れた変数</title>
</head>
<body>
<pre>
<?php
// 変数を使ってメンバーの名前を管理する
$name1 = "赤井一郎";
$name2 = "伊藤五郎";
$name3 = "上野信二";
$name4 = "江藤幸代";
$name5 = "小野幸子";
?>
</pre>
</body>
</html>

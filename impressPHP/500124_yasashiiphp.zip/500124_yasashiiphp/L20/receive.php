<?php
print_r($_POST);
echo htmlspecialchars($_POST['recipe_name'],ENT_QUOTES,'UTF-8');
?>
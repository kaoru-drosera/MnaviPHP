<?php
$user = "●●●";
$pass = "●●●";
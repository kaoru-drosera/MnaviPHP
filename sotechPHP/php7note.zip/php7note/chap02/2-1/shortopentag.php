<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>PHPタグの省略形</title>
</head>
<? echo "こんにちは"; ?>
</body>
</html>

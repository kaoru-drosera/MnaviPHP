<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>ダブルクォートの文字列の中に$記号を含める</title>
</head>
<?php
$yen = 117;
echo "今日のレートは、\$1 = $yen 円です。";
?>
</body>
</html>

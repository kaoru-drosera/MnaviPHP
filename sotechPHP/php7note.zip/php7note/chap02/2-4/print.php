<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>print()で値を表示する例</title>
</head>
<body>
<?php
$msg = "ハローグッバイ";
print($msg);
?>
</body>
</html>

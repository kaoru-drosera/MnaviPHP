<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>連想配列を作る</title>
</head>
<body>
<pre>
<?php
// 連想配列を作る
$goods = [
  "id" => "R56",
  "size" => "M",
  "price" => 2340
];
// 確認する
print_r($goods);
?>
</pre>
</body>
</html>

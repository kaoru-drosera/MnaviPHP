<?php
function double($n){
  $result = $n * 2;
  return $result;
}
?>

<?php
$ans = double(125);
echo $ans;
?>

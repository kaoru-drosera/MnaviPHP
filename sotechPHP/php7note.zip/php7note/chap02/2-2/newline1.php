<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>echo</title>
</head>
<body>
<?php
echo "みなさん、";
echo "こんにちは";
?>
</body>
</html>

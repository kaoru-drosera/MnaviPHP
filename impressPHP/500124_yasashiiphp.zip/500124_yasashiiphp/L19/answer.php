<?php
$a = 1;
$b = 2;
$answer = $a + $b;
echo $answer;
?>
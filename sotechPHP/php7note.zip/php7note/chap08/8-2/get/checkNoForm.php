<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>フォーム入力処理の基本（GET）</title>
<link href="../../css/style.css" rel="stylesheet">
</head>
<body>
<div>

<form method="GET" action="checkNo.php">
  <ul>
    <li><label>番号：<input type="number" name="no"></label></li>
    <li><input type="submit" value="調べる" /></li>
  </ul>
</form>

</div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>連想配列を作る</title>
</head>
<body>
<pre>
<?php
// 連想配列を作る
$user = [];
$user['name'] = "井上萌";
$user['yomi'] = "いのうえもえ";
$user['age'] = 28;
// 確認する
print_r($user);
?>
</pre>
</body>
</html>

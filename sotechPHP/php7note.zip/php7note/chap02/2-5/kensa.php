<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>値が10以上のときに合格</title>
</head>
<body>
<?php
$point = 11.6;
if ($point >= 10) {
  echo "合格";
} else {
  echo "失格";
}
?>
</body>
</html>

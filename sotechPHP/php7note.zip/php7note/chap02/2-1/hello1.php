<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>「こんにちは」と表示する</title>
</head>
<body>
<?php
echo "こんにちは";
?>
</body>
</html>

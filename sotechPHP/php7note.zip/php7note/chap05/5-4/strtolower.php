<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>大文字を小文字にする</title>
</head>
<body>
<?php
$msg = "Apple iPhone";
echo strtolower($msg);
?>
</body>
</html>

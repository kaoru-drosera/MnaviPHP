<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>型指定子の%の例</title>
</head>
<body>
<?php
$per = 64.8;
printf('達成率は%.2f%%です。', $per);
?>
</body>
</html>

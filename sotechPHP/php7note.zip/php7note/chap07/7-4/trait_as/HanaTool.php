<?php
// HanaToolトレイトを定義する
trait HanaTool {
  public function hello() {
    echo "ごきげんよう。";
  }
}
// ?>

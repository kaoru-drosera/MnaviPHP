<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>var_dump()をブラウザでも見やすく出力する</title>
</head>
<body>
<pre>
<?php
$colors = array("red", "blue", "green");
var_dump($colors);
?>
</pre>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>コメント</title>
</head>
<body>
<?php
echo "こんにちは。";
/*
// この区間はコメントです。
echo "ありがとう。";
*/
echo /*途中をコメント*/ "さようなら。";
?>
</body>
</html>

<?php
$msg = "<p><b>北原白秋『砂山』</b>海は荒海<br>向こうは佐渡よ<br></p>";
echo strip_tags($msg);
?>

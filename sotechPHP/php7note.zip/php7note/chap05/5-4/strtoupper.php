<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>小文字を大文字にする</title>
</head>
<body>
<?php
$msg = "Apple iPhone";
echo strtoupper($msg);
?>
</body>
</html>

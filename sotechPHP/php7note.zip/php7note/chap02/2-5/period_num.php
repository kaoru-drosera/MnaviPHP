<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>数値をピリオド連結する</title>
</head>
<body>
<pre>
<?php
$num = 19 + 1;
$msg1 = $num . "番" . PHP_EOL;
$msg2 = $num . 77;
echo $msg1;
echo $msg2;
?>
</pre>
</body>
</html>

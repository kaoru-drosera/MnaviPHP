﻿<?php
$a = "いちばんやさしい";
$b = "PHP";
$title = $a . $b;
echo $title;
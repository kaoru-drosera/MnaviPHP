<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>配列を定数にする</title>
</head>
<body>
<?php
define("RANK", ["松", "竹", "梅"]);
echo RANK[1];
?>
</body>
</html>

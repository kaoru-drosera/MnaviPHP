<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>85点だったとき</title>
</head>
<body>
<?php
$tokuten = 85;
if ($tokuten>=80) {
  echo "素晴らしい!";
}
echo "{$tokuten}点でした。"
?>
</body>
</html>

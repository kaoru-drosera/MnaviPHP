<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>単語の先頭文字だけ大文字にする</title>
</head>
<body>
<?php
$msg = "THE QUICK BROWN FOX";
echo ucwords(strtolower($msg));
?>
</body>
</html>

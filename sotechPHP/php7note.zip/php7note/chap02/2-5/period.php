<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>文字列を連結する</title>
</head>
<body>
<?php
$who = "青島";
$hello = "こんにちは";
$msg = $who . "さん。" . $hello;
echo $msg;
?>
</body>
</html>

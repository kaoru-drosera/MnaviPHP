<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>可変変数</title>
</head>
<body>
<?php
$color = "red";
$$color = 125;
echo $red;
 ?>
</body>
</html>

<?php
/**
 * いちばんやさしいPHPの教本 サンプルコード
 * 2017 Copyright(c) Alleyoop inc. (http://alleyoop.jp)
 *
 * db_config.php データベース設定（ユーザ名、パスワード)ファイル
 * $user,$passの値はphpMyAdminで作成した値に変更してください。
 */
$user = "●●●";
$pass = "●●●";
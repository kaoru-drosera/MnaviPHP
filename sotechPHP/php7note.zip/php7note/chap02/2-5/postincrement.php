<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>値を代入した後で1を加算する</title>
</head>
<body>
<?php
$a = 0;
$b = $a++;
echo "\$aは{$a}、\$bは{$b}";
?>
</body>
</html>

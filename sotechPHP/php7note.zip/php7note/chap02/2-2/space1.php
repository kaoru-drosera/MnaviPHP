<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>スペースと改行</title>
</head>
<body>
<?php
$name  = "佐藤";
$age   = 16;

echo $name,"、",
     $age;
 ?>
</body>
</html>

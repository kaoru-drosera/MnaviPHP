<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>50点だったとき</title>
</head>
<body>
<?php
$tokuten = 50;
if ($tokuten>=80) {
  echo "素晴らしい!";
}
echo "{$tokuten}点でした。"
?>
</body>
</html>

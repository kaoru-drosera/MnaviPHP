<?PHP
$a = 0;
var_dump(empty($a));
var_dump(!isset($a));
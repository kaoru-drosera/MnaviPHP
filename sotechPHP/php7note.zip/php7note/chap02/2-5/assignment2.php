<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>変数に値を代入する</title>
</head>
<body>
<pre>
<?php
$a = $b = $c = 100;
var_dump($a);
var_dump($b);
var_dump($c);
?>
</pre>
</body>
</html>

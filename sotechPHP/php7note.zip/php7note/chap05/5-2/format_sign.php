<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>数値が負のとき-、正のとき+を付けて表示する</title>
</head>
<body>
<?php
$a = -5;
$b = 9;
printf('%+d', $a);
echo "、";
printf('%+d', $b);
?>
</body>
</html>

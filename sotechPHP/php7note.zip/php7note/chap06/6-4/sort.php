<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>配列を昇順にソートする</title>
</head>
<body>
<pre>
<?php
$data = [23, 16, 8, 42, 15, 4];
// 昇順にソートする
sort($data);
print_r($data);
?>
</pre>
</body>
</html>

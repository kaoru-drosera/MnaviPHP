<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="utf-8">
<title>フォーム入力</title>
<link href="../../css/style.css" rel="stylesheet">
</head>
<body>
<div>
  <form method="POST" action="nameCheck.php">
    <ul>
      <li><label>名前：<input type="text" name="name"></label></li>
      <li><input type="submit" value="送信する"></li>
    </ul>
  </form>
</div>
</body>
</html>

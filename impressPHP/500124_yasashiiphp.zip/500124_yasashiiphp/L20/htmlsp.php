<form method="POST" action="htmlsp.php">
<input type="text" name="test">
<input type="submit">
</form>
<?php
echo $_POST['test'];
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>print()で値を表示する例</title>
</head>
<body>
<?php
$who = "田中";
$age = 35;
print $who . "さん。" . $age . "才";
?>
</body>
</html>

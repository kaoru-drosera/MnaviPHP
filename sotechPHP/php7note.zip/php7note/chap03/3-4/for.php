<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>処理を10回繰り返す</title>
</head>
<body>
<?php
for ($i=0; $i<10; $i++){
  echo "{$i}回。";
}
?>
</body>
</html>

<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8">
  <title>Page 2</title>
  <link href="../../css/style.css" rel="stylesheet">
</head>
<body>
<div>
  <a href="page1.php">Page 1に戻る</a>
</div>
</body>
</html>

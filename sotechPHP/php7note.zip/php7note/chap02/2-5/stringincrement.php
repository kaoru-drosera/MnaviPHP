<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>文字列をインクリメントする</title>
</head>
<body>
<?php
$myNum = "19";
$myChar = "a";
++$myNum;
++$myChar;
echo "\$myNumは{$myNum}、\$myCharは{$myChar}";
?>
</body>
</html>

<?php
// エラーメッセージを表示する
ini_set('display_errors', 1);
// すべてのエラーレベルをレポートする
error_reporting(E_ALL);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>エラーを表示する</title>
</head>
<body>
<?php
echo "行区切り忘れ"
echo "ハローワールド";
?>
</body>
</html>

<?php
ini_set('display_errors', 0);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>エラーを表示する</title>
</head>
<body>
<?php
echo "行区切り忘れ"
echo "ハローワールド";
?>
</body>
</html>
